#include "../com_lyle_jni_TestNative.h"
#include<iostream>
using namespace std;


JNIEXPORT void JNICALL Java_com_lyle_jni_TestNative_sayHello(JNIEnv * env, jobject obj)
{
	cout << "Congratulations! If you see this page That means you're successful" << endl;
}